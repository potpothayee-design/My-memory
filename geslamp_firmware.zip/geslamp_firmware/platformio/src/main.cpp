// PlatformIO needs a source file here. This just includes the real sketch so
// there is exactly one copy of the firmware to maintain.
#include "../../geslamp_firmware/geslamp_firmware.ino"
