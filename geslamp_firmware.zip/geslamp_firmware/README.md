# Geslamp firmware

Arduino Mega 2560 firmware for the smart lamp arm — 3 servos + LED, driven over
Bluetooth from the App Inventor app **`final_on_and_off_only1`**.

---

## 1. What to open

| You use | Open this |
|---|---|
| **Arduino IDE** | `geslamp_firmware/geslamp_firmware.ino` — the folder name must match the `.ino` name |
| **VS Code + PlatformIO** | the `platformio/` folder in this zip (it already points at the `.ino`) |

Install the **`Servo`** library if the IDE asks (it ships with the IDE; usually nothing to do).

Board: **Arduino Mega or Mega 2560**
Port: whatever appears when you plug the Mega in.

---

## 2. Wiring

### Bluetooth module (HC-05 / HC-08 / HM-10)

| Module pin | Mega pin |
|---|---|
| VCC | 5V |
| GND | GND |
| TXD | **19** (RX1) |
| RXD | **18** (TX1) — through a **1k + 2k voltage divider** if it's a 3.3 V module |

### Servos and LED

| Part | Mega pin | Travel |
|---|---|---|
| **Head** servo | **5** | 45° – 135° |
| **LED** | **6** | PWM brightness 0–255 |
| **Elbow** servo | **7** | 30° – 150° |
| **Base** servo | **9** | 0° – 300° |

### Power — read this before you wire it

**Power the servos from a separate 5 V supply with a common ground.**
Three servos on the Mega's own 5 V regulator will brown it out: the board
resets mid-command, Bluetooth drops, and it looks like a software bug.

Danger pins to avoid:

| Pin | Why |
|---|---|
| 44, 45, 46 | The Mega's Servo library claims **Timer5** — no PWM here |
| 18, 19 | That's **Serial1**, the Bluetooth link |
| 2 | Cannot receive on a Mega (why we don't use SoftwareSerial) |

Pin 6 is a **Timer4** pin, so `analogWrite()` on it is safe alongside Servo.

---

## 3. Commands

Every command ends with `#`. This matches what the app sends — you don't have to
type any of it.

| Command | Meaning |
|---|---|
| `H<deg>#` | Head to an absolute angle, clamped 45–135 |
| `E<deg>#` | Elbow absolute, clamped 30–150 |
| `B<deg>#` | Base absolute, clamped 0–300 |
| `H+` `H-` `E+` `E-` `B+` `B-` | Step 5° (hand-typed only — the app sends absolutes) |
| `ON#` | LED on at the last brightness |
| `OFF#` | LED off |
| `P<0-100>#` | Brightness percent |
| `M0#` / `M1#` | Mobile / gesture mode |
| `TW#` `TN#` `TC#` | Warm / neutral / cool presets (35 / 60 / 100 %) |
| `S<deg>#` | Bench test: moves the base, echoes the angle |

Compounding works, because the parser splits on `#`:

```
B175#E90#H90#
```

That's the app's "Reset Position" — parks everything at head 90, elbow 90, base 175.

Every accepted command replies `OK <value>` over Bluetooth, so the app sees the
link is alive.

---

## 4. Testing without the phone

1. Open **Tools → Serial Monitor**, set **9600 baud**.
2. Type `B175#` and press Enter → the base should move.
3. Type `ON#` → the LED lights.

On power-up the sketch prints a banner and parks the arm at home.

---

## 5. Calibration

### The base is a 300° servo

`Servo.write()` only accepts **0–180**, so a 300° servo driven with `write()`
silently stops at 180 and never uses its last third of travel. This sketch uses
`writeMicroseconds()` with a mapped range instead.

The defaults are:

```cpp
const int BASE_MIN_US = 500;
const int BASE_MAX_US = 2500;
```

**If the base buzzes, strains, or hits a mechanical stop before the app reads
0° or 300°, narrow these values.** Try `700` / `2300`, then `800` / `2200`.
Each step inward costs a little travel but protects the servo.

Never "fix" this with `write(2500)` — on AVR any value ≥ 544 passed to `write()`
is reinterpreted as **microseconds**, so it jumps instead of sweeping.

### Head and elbow

```cpp
const int STD_MIN_US = 544;
const int STD_MAX_US = 2400;
```

These are standard 180° servo pulses. If either joint binds before reaching its
limit, tighten the limits in two places — they must agree:

- the sketch (`HEAD_MIN` / `HEAD_MAX`, `ELBOW_MIN` / `ELBOW_MAX`)
- the app (`final_on_and_off_only1.aia` clamps the same four numbers)

---

## 6. If nothing moves

| Symptom | Cause |
|---|---|
| Garbage / `255` / `254` bytes on serial | Baud mismatch — the module isn't at 9600 |
| Nothing at all | Not paired, or another app (a Bluetooth terminal) still holds the link. **Only one device can connect to the module at a time.** |
| Connects then drops | Servo power — almost always the brown-out in §2 |
| Base moves but head/elbow don't | Servos not wired, or on a pin claimed by Timer5 |
| Moves but the app says OFFLINE | The app connects to a hard-coded MAC; check `btAddress` in the app's `Screen1.Initialize` |

---

## 7. Bluetooth type — important

This firmware speaks plain **serial over Bluetooth**:

- **HC-05** — classic Bluetooth. Needs a `BluetoothClient` app, **not** the BLE extension.
- **HC-08 / HM-10 / AT-09** — BLE. Works with the `BluetoothLE` extension the app currently uses.

The app `final_on_and_off_only1` uses **`BluetoothLE`** (service `0000ffe0`,
characteristic `0000ffe1`). That only works if the module is a **BLE** module.
A genuine **HC-05 will never connect** to it, whatever address you set.
