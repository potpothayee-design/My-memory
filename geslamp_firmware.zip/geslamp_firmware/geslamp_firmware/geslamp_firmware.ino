/*
  ===========================================================================
   GESLAMP  -  Smart Lamp Arm firmware
   Arduino Mega 2560  +  HC-05/HC-08 Bluetooth  +  3 servos  +  LED
  ===========================================================================

  Matches the command protocol of the App Inventor app
  "final_on_and_off_only1" exactly. Every command ends with '#'.

  ---------------------------------------------------------------------------
  WIRING
  ---------------------------------------------------------------------------
    Bluetooth module          Arduino Mega 2560
  -------------------------  ----------------------------------------------
    VCC                        5V
    GND                        GND
    TXD                        pin 19  (RX1)
    RXD                        pin 18  (TX1)   <-- use a voltage divider
                                                   (1k + 2k) on a 3.3V module

    Servo                Mega pin     Range
  -------------------  ----------   --------------------------
    Head                 5            45 .. 135 deg
    Elbow                7            30 .. 150 deg
    Base                 9             0 .. 300 deg  (300 deg servo)
    LED                  6            PWM brightness 0 .. 255

  IMPORTANT - do not change these pins without reading this:
    * The Mega's Servo library claims Timer5, so PWM is NOT available on
      pins 44, 45, 46. Not used here.
    * Pin 6 is a Timer4 pin -> analogWrite() on it is safe alongside Servo.
    * Do NOT use pins 18/19 for anything else: that is Serial1, the Bluetooth
      link.
    * Pin 2 cannot receive on a Mega - that is why Serial1 is used instead of
      SoftwareSerial.
    * Power the servos from a separate 5V supply with a common GND. Three
      servos on the Mega's own 5V regulator will brown it out and reset the
      board mid-command.

  ---------------------------------------------------------------------------
  COMMANDS  (sent by the app, all terminated with '#')
  ---------------------------------------------------------------------------
    H<deg>#     Move head absolutely, clamped 45..135
    E<deg>#     Move elbow absolutely, clamped 30..150
    B<deg>#     Move base absolutely,  clamped 0..300
    H+# H-#     Step head   by STEP_DEG in that direction
    E+# E-#     Step elbow  by STEP_DEG
    B+# B-#     Step base   by STEP_DEG
    ON#         LED on at last brightness
    OFF#        LED off
    P<0-100>#   Set brightness, 0..100 %
    M0#         Mobile mode  (manual controls enabled)
    M1#         Gesture mode (manual controls locked by the app)
    TW# TN# TC# Light colour preset (warm / neutral / cool) - see below

  Compounding works, because commands are split on '#':
    B175#E90#H90#     reset to home position (what the app sends)

  Every accepted command replies "OK <what>" so the Serial Monitor shows the
  link is alive.
  ===========================================================================
*/

#include <Servo.h>

// ---------------------------------------------------------------------------
// Pin map
// ---------------------------------------------------------------------------
const int HEAD_PIN  = 5;
const int LED_PIN   = 6;
const int ELBOW_PIN = 7;
const int BASE_PIN  = 9;

// Bluetooth runs on Serial1 (pins 19 = RX1, 18 = TX1)
#define BT Serial1

// ---------------------------------------------------------------------------
// Travel limits - must match the ranges the app enforces
// ---------------------------------------------------------------------------
const int HEAD_MIN  = 45,  HEAD_MAX  = 135;
const int ELBOW_MIN = 30,  ELBOW_MAX = 150;
const int BASE_MIN  = 0,   BASE_MAX  = 300;

// Degrees per H+/H-/E+/E-/B+/B- step.
// The app's own tap step is 5 deg and its hold step is 1 deg per 100 ms, so
// the app normally sends absolute angles. These are the fallback for a bare
// terminal, and match the app's tap behaviour.
const int STEP_DEG = 5;

// Brightness used by ON# when no level has ever been set.
const int DEFAULT_BRIGHTNESS = 50;

// Position the app starts from and returns to on "Reset Position"
const int HEAD_HOME  = 90;
const int ELBOW_HOME = 90;
const int BASE_HOME  = 175;

// ---------------------------------------------------------------------------
// 300-degree base calibration
// ---------------------------------------------------------------------------
// Servo.write() only accepts 0..180, so a 300-degree servo cannot be driven
// with write(). writeMicroseconds() over a mapped range is used instead.
//
//   write(2500) would NOT work: on AVR any value >= 544 is reinterpreted as a
//   pulse width in microseconds.
//
// Narrow MIN_US / MAX_US if the base buzzes or strains at either end.
const int BASE_MIN_US = 500;
const int BASE_MAX_US = 2500;

// Head and elbow are standard 180-degree servos.
const int STD_MIN_US = 544;
const int STD_MAX_US = 2400;

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
Servo headServo, elbowServo, baseServo;

int headAngle  = HEAD_HOME;
int elbowAngle = ELBOW_HOME;
int baseAngle  = BASE_HOME;

int brightness    = 50;    // percent
int ledDuty       = 0;     // 0..255, what is actually on the pin
bool ledOn        = false;
// ON# uses this, so it must be non-zero from power-up. The lamp still starts
// dark because ledOn is false and setup() calls ledPercent(0).
int lastBrightness = 50;

bool mobileMode = true;

// Serial receive buffers
String btBuf = "";
String usbBuf = "";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
int clampInt(int v, int lo, int hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

// Drive the 300-degree base with an explicit pulse range.
void writeBase(int deg) {
  deg = clampInt(deg, BASE_MIN, BASE_MAX);
  baseAngle = deg;
  long us = map(deg, BASE_MIN, BASE_MAX, BASE_MIN_US, BASE_MAX_US);
  baseServo.writeMicroseconds((int)us);
}

// Drive a standard 180-degree servo with a calibrated pulse range too, so head
// and elbow behave consistently with the base.
void writeStd(Servo &s, int deg, int lo, int hi) {
  deg = clampInt(deg, lo, hi);
  long us = map(deg, 0, 180, STD_MIN_US, STD_MAX_US);
  s.writeMicroseconds((int)us);
}

void setHead(int deg) {
  headAngle = clampInt(deg, HEAD_MIN, HEAD_MAX);
  writeStd(headServo, headAngle, HEAD_MIN, HEAD_MAX);
}

void setElbow(int deg) {
  elbowAngle = clampInt(deg, ELBOW_MIN, ELBOW_MAX);
  writeStd(elbowServo, elbowAngle, ELBOW_MIN, ELBOW_MAX);
}

void setBase(int deg) {
  writeBase(deg);
}

// Brightness is a percentage; the pin wants 0..255.
void applyLed() {
  ledDuty = ledOn ? (brightness * 255) / 100 : 0;
  analogWrite(LED_PIN, ledDuty);
}

void ledPercent(int pct) {
  brightness = clampInt(pct, 0, 100);
  if (brightness > 0) {
    lastBrightness = brightness;
    ledOn = true;
  } else {
    ledOn = false;
  }
  applyLed();
}

// ---------------------------------------------------------------------------
// Command handling
// ---------------------------------------------------------------------------
// Splits "<letter><payload>" apart. Returns false if the command is unusable.
bool splitCmd(const String &cmd, char &kind, String &payload) {
  if (cmd.length() < 1) return false;
  kind = cmd.charAt(0);
  payload = cmd.substring(1);
  return true;
}

void handleCommand(String cmd) {
  cmd.trim();
  if (cmd.length() == 0) return;

  char kind;
  String payload;
  if (!splitCmd(cmd, kind, payload)) return;

  // ---- two-letter light presets, checked before the single-letter forms ----
  if (cmd == "TW" || cmd == "TN" || cmd == "TC") {
    // No RGB channel on this build: a single white LED on pin 6. The presets
    // are accepted so the app never gets a dead command, and they nudge
    // brightness to a sensible level for each mood.
    if (cmd == "TW")      ledPercent(35);   // warm   - dim, cosy
    else if (cmd == "TN") ledPercent(60);   // normal - everyday
    else                  ledPercent(100);  // cool   - full, task light
    BT.print("OK "); BT.println(cmd.c_str());
    Serial.print("[BT] "); Serial.println(cmd.c_str());
    return;
  }

  // ---- mode ----
  if (cmd == "M0" || cmd == "M1") {
    mobileMode = (cmd == "M0");
    BT.print("OK "); BT.println(cmd.c_str());
    Serial.print("[BT] "); Serial.print(cmd.c_str());
    Serial.println(mobileMode ? " (mobile)" : " (gesture)");
    return;
  }

  // ---- light on / off ----
  if (cmd == "ON") {
    brightness = lastBrightness > 0 ? lastBrightness : DEFAULT_BRIGHTNESS;
    ledOn = true;
    applyLed();
    BT.println("OK ON");
    Serial.println("[BT] ON");
    return;
  }
  if (cmd == "OFF") {
    ledOn = false;
    applyLed();
    BT.println("OK OFF");
    Serial.println("[BT] OFF");
    return;
  }

  // ---- single letter + numeric payload ----
  // Two forms arrive from the app:
  //     H+   H-   E+   E-   B+   B-      no number at all  -> step STEP_DEG
  //     H90# E120# B175#                  bare number       -> absolute angle
  //     H+10 H-10                         optional: number after the sign
  bool relative = false;
  int  dir      = 1;
  String num    = payload;

  if (payload.startsWith("+"))      { relative = true;  dir =  1; num = payload.substring(1); }
  else if (payload.startsWith("-")) { relative = true;  dir = -1; num = payload.substring(1); }

  // An empty tail is legal for the relative form: H+ means "one step up".
  if (num.length() == 0 && !relative) {
    Serial.print("[BT] no value in: "); Serial.println(cmd.c_str());
    return;
  }
  int value = (num.length() == 0) ? STEP_DEG : num.toInt();

  switch (kind) {
    case 'H': {
      int target = relative ? headAngle + dir * value : value;
      setHead(target);
      BT.print("OK H"); BT.println(headAngle);
      Serial.print("[BT] head -> "); Serial.println(headAngle);
      break;
    }
    case 'E': {
      int target = relative ? elbowAngle + dir * value : value;
      setElbow(target);
      BT.print("OK E"); BT.println(elbowAngle);
      Serial.print("[BT] elbow -> "); Serial.println(elbowAngle);
      break;
    }
    case 'B': {
      int target = relative ? baseAngle + dir * value : value;
      setBase(target);
      BT.print("OK B"); BT.println(baseAngle);
      Serial.print("[BT] base -> "); Serial.println(baseAngle);
      break;
    }
    case 'P': {
      ledPercent(value);
      BT.print("OK P"); BT.println(brightness);
      Serial.print("[BT] brightness -> "); Serial.println(brightness);
      break;
    }
    case 'S': {
      // Servo test kept for bench work: moves the base and echoes.
      setBase(value);
      BT.print("OK S"); BT.println(baseAngle);
      Serial.print("[BT] servo-test base -> "); Serial.println(baseAngle);
      break;
    }
    default:
      Serial.print("[BT] ignored: "); Serial.println(cmd.c_str());
      break;
  }
}

// A bare sign command (H+, H-, E+, E-, B+, B-) is a single step. The app
// always sends an absolute angle terminated with '#', so this only matters
// when typing by hand in the Serial Monitor - but a sign that sat in the
// buffer un-terminated would otherwise never fire.
bool isBareStep(const String &s) {
  if (s.length() != 2) return false;
  char k = s.charAt(0);
  char v = s.charAt(1);
  return (k == 'H' || k == 'E' || k == 'B') && (v == '+' || v == '-');
}

// Collect characters until '#'. Anything else printable is buffered; \r and
// \n are dropped; a runaway buffer is reset so a garbled link recovers.
void feed(char c, String &buf, const char *source) {
  if (c == '#') {
    if (buf.length() > 0) handleCommand(buf);
    buf = "";
    return;
  }
  if (c == '\r' || c == '\n') {
    // A line break also flushes, so a bare H+ followed by Enter still works.
    if (isBareStep(buf)) handleCommand(buf);
    buf = "";
    return;
  }
  if ((uint8_t)c < 32 || (uint8_t)c > 126) return;   // ignore line noise
  buf += c;
  if (buf.length() > 24) buf = "";
  (void)source;
}

// ---------------------------------------------------------------------------
// Setup
// ---------------------------------------------------------------------------
void setup() {
  Serial.begin(9600);   // USB Serial Monitor
  BT.begin(9600);       // HC-05 factory baud

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  headServo.attach(HEAD_PIN);
  elbowServo.attach(ELBOW_PIN);
  baseServo.attach(BASE_PIN, BASE_MIN_US, BASE_MAX_US);

  // Park in the same home position the app assumes.
  setHead(HEAD_HOME);
  setElbow(ELBOW_HOME);
  setBase(BASE_HOME);
  ledPercent(0);

  Serial.println();
  Serial.println(F("==========================================="));
  Serial.println(F("  GESLAMP  -  head p5  elbow p7  base p9"));
  Serial.println(F("              LED p6                      "));
  Serial.println(F("==========================================="));
  Serial.print(F("  head "));  Serial.print(headAngle);
  Serial.print(F("  elbow ")); Serial.print(elbowAngle);
  Serial.print(F("  base "));  Serial.println(baseAngle);
  Serial.println(F("  Waiting for the phone app (9600 baud)..."));
  Serial.println();
  Serial.println(F("  Try:  B175#E90#H90#   ON#   P50#   OFF#"));
  Serial.println(F("  Garbage bytes = baud mismatch."));
  Serial.println();

  BT.println("OK READY");
}

// ---------------------------------------------------------------------------
// Loop
// ---------------------------------------------------------------------------
void loop() {
  while (BT.available()) {
    feed((char)BT.read(), btBuf, "BT");
  }
  while (Serial.available()) {
    feed((char)Serial.read(), usbBuf, "USB");
  }
}
